$(document).ready(()=> {
    // hamburger on admin
    $("#hamburgerAdmin").click(()=> {
        if($("#navBarAd").hasClass("open")){
            document.getElementById("navBarAd").style.marginLeft = "0%"
            $("#navBarAd").removeClass("open")
        }
        else {
            document.getElementById("navBarAd").style.marginLeft = "-100%"
            $("#navBarAd").addClass("open")
        }
    })

    // fixing the weird bug of hamburger menu not defaulting when screen size changes
    $(window).resize(function() {
        if ($(window).width() >= 1024) {
            if($('#navBarAd').css('margin-left', '-100%')){
                $('#navBarAd').css('margin-left', '0')
            }
        }
    });

    $('addStudentOfficerForm').on('submit', function(e) {
      e.preventDefault()
    })

    
})

// validate form for admin settings page

// validate form for admin accounts page




positionInputPrefix = "<span class = 'flex relative items-center w-full'>"
inputContent1 = "<input type='text' name='positionName[]' placeholder='Enter position name' class='positionField pr-20 w-full border-1 mb-2 border-gray-100 rounded-md shadow-sm focus:border-greenBPC focus:ring-0' required>"
inputContent2 = "<button class = 'absolute right-2 top-0 bottom-2 my-2 rounded-md text-white text-sm px-2 bg-red-600 hover:bg-red-800' onclick='return this.parentNode.remove()'>Delete</button>"
positionInputSuffix = "</span>"

function addPosition(element) {
  spanID = element.previousElementSibling.id
  content = `${positionInputPrefix} ${inputContent1} ${inputContent2} ${positionInputSuffix}`
  $(`#${spanID}`).append(content)
}
// Fetch all the details element.
const details = document.querySelectorAll("details");

// Add the onclick listeners.
details.forEach((targetDetail) => {
  targetDetail.addEventListener("click", () => {
    // Close all the details that are not targetDetail.
    details.forEach((detail) => {
      if (detail !== targetDetail) {
        detail.removeAttribute("open");
      }
    });
  });
});

// enable/disable edit on settings
function editInfoToggle(element){
  prevId = element.previousElementSibling.id
  inputEditable = document.getElementById(prevId)
  inputEditable.disabled = false
  inputEditable.style.borderColor = "green"
  element.style.display = "none";
}
// view election donut chart
function donutChart(element){
  
  const dataDoughnut = {
    labels: ["Total Voters", "Voted"],
    datasets: [
      {
        label: "My First Dataset",
        data: [300, 50],
        backgroundColor: [
          "rgb(133, 105, 241)",
          "rgb(164, 101, 241)",
        ],
        hoverOffset: 2,
      },
    ],
  };
  const configDoughnut = {
    type: "doughnut",
    data: dataDoughnut,
    options: {},
  };

  var chartBar = new Chart(
    document.getElementById(element),
    configDoughnut
  );
}
